DROP TABLE IF EXISTS `diary_parameters`;
CREATE TABLE `diary_parameters` (
  `id` int(11) NOT NULL DEFAULT '1',
  `password_hash` text NOT NULL,
  `points_on_page` int(11) NOT NULL DEFAULT '10',
  `versions_of_backups` int(11) NOT NULL DEFAULT '3',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `diary_parameters` VALUES
	('1', '$2a$13$7RC2CWHDqafP4dvl7t5PCucccPVl7spVT4FiALXEaxWCnzCTskqAK', '10', '3');

DROP TABLE IF EXISTS `diary_points`;
CREATE TABLE `diary_points` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `text` text NOT NULL,
  `state` enum('INITIAL','SATISFIED','NOT_SATISFIED','CANCELED') NOT NULL DEFAULT 'INITIAL',
  `check` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

INSERT INTO `diary_points` VALUES
	('6', '2013-10-24', 'запись 3', 'SATISFIED', '1'),
	('5', '2013-10-24', 'запись 2', 'SATISFIED', '1'),
	('4', '2013-10-24', 'запись 1', 'SATISFIED', '1');
