<?php

/* @var $this PointController */
/* @var $model Point */

$this->pageTitle = Yii::app()->name . ' - Изменить пункт';

$this->renderPartial('_form', array('model' => $model));
