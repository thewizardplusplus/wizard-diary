<?php

class Constants {
	const COPYRIGHT_START_YEAR = 2013;
}
